# bit-286-mathgame
Math Game Project Repository for Team Kismet BIT 286
